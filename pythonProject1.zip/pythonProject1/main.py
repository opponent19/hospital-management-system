from tkinter import*
from tkinter import ttk,messagebox


from PIL import Image, ImageTk#pip install pillow

import pymysql
class Register:
    def __init__(self, root, farme1=None):
        self.root=root
        self.root.title("Registration window")
        self.root.geometry("1350x700+0+0")
        self.root.config(bg="white")

        #===============bg image===========
        self.bg = ImageTk.PhotoImage(file="images/e.jpg")
        bg=Label(self.root,image=self.bg).place(x=250,y=0,relwidth=1,relheight=1)

        #===============left image===========
        self.left=ImageTk.PhotoImage(file="images/d.jpg")
        left=Label(self.root,image=self.left).place(x=0,y=80,width=700,height=400)

        #===============Rgister frame===========
        frame1 = Frame(self.root,bg="white")
        #frame1.place(x=400,y=0,width=800,height=700)

        title = Label(farme1,text="Register Here",font=("times new roman",20,"bold"),bg="white",fg="green").place(x=50,y=30)
        #==============row1

        f_name = Label(farme1, text="First Name", font=("times new roman", 17, "bold"), bg="cyan", fg="gray").place(
            x=50, y=100)
        self.txt_fname=Entry(font=("times new roman", 17),bg="alice blue")
        self.txt_fname.place(x=50,y=130,width=250)

        l_name = Label( text="Last Name", font=("times new roman", 17, "bold"), bg="cyan", fg="gray").place(
            x=370, y=100)
        self.txt_lname = Entry( font=("times new roman", 17), bg="AliceBlue")
        self.txt_lname.place(x=370, y=130, width=250)

        #===============row2
        contact= Label(farme1, text="Contact No.", font=("times new roman", 17, "bold"), bg="cyan", fg="gray").place(
            x=50, y=170)
        self.txt_contact= Entry(font=("times new roman", 17), bg="alice blue")
        self.txt_contact.place(x=50, y=200, width=250)

        email = Label(text="Email", font=("times new roman", 17, "bold"), bg="cyan", fg="gray").place(
            x=370, y=170)
        self.txt_email = Entry(font=("times new roman", 17), bg="AliceBlue")
        self.txt_email.place(x=370, y=200, width=250)


        # ===============row3
        question = Label(farme1, text="Security Question", font=("times new roman", 17, "bold"), bg="cyan",
                         fg="gray").place(
            x=50, y=240)
        self.cmb_quest = ttk.Combobox(font=("times new roman", 15),state='readonly',justify=CENTER)
        self.cmb_quest['values']=("Select","Your First Pet Name","Your Birth Place","Your best Friend Name")
        self.cmb_quest.place(x=50, y=270, width=250)
        self.cmb_quest.current(0)
        answer = Label(text="Answer", font=("times new roman", 17, "bold"), bg="cyan", fg="gray").place(
            x=370, y=240)
        self.txt_answer = Entry(font=("times new roman", 17), bg="AliceBlue")
        self.txt_answer.place(x=370, y=270, width=250)

        # ===============row4
        password = Label(farme1, text="Password", font=("times new roman", 17, "bold"), bg="cyan", fg="gray").place(
            x=50, y=310)
        self.txt_password = Entry(font=("times new roman", 17), bg="alice blue")
        self.txt_password.place(x=50, y=340, width=250)

        cpassword = Label(text="Confirm Password", font=("times new roman", 17, "bold"), bg="cyan", fg="gray").place(
            x=370, y=310)
        self.txt_cpassword = Entry(font=("times new roman", 17), bg="AliceBlue")
        self.txt_cpassword.place(x=370, y=340, width=250)


        #=================terms
        self.var_chk=IntVar()
        chk=Checkbutton(text="I Agree The Terms And Condition",variable=self.var_chk,onvalue=1,offvalue=0,bg="AliceBlue", font=("times new roman",15)).place(x=50,y=380)

        btn_register = Button(self.root, text="Register", font=("times new roman", 17), bg="red", cursor="hand2",command=self.register_data).place(x=50,
                                                                                                                y=420)
        '''self.btn_img=ImageTk.PhotoImage(file="images/register.png")
        btn_register=Button(image=self.btn_img,bd=0,cursor="hand2").place(x=50,y=420)'''

        btn_login= Button(self.root,text="Sign in", font=("times new roman", 17),bd=0,cursor="hand2").place(x=400, y=420)

    def clear(self):
        self.txt_fname.delete(0,END)
        self.txt_lname.delete(0, END)
        self.txt_contact.delete(0, END)
        self.txt_email.delete(0, END)
        self.txt_answer.delete(0, END)
        self.txt_password.delete(0, END)
        self.txt_cpassword.delete(0, END)
        self.cmb_quest.current(0)




    def register_data(self):
        if self.txt_fname.get()=="" or self.txt_contact.get()=="" or self.txt_email.get()=="" or self.cmb_quest.get()=="Select" or self.txt_answer.get()=="" or self.txt_password.get()=="" or self.txt_cpassword.get()=="":
            messagebox.showerror("Error","All Fields Are Required",parent=self.root)
        elif self.txt_password.get()!= self.txt_cpassword.get():
            messagebox.showerror("Error", "Password & Confirm Password should be same", parent=self.root)
        elif self.var_chk.get()==0:
            messagebox.showerror("Error", "Please Agree our terms and condition", parent=self.root)

        else:
            try:
                con=pymysql.connect(host="localhost",user="root",password="",database="employee")
                cur=con.cursor()
                cur.execute("select * from employee where email=%s",self.txt_email.get())
                row=cur.fetchone()
                #print(row)
                if row!=None:
                    messagebox.showerror("Error", "User already exist plzz try with another email", parent=self.root)
                else:
                    cur.execute("insert into employee (f_name,l_name,contact,email,question,answer,password) values(%s,%s,%s,%s,%s,%s,%s)",
                                (self.txt_fname.get(),
                                self.txt_lname.get(),
                                self.txt_contact.get(),
                                self.txt_email.get(),
                                self.cmb_quest.get(),
                                self.txt_answer.get(),
                                self.txt_password.get()
                            ))
                    con.commit()
                    con.close()
                    messagebox.showinfo("Success","Register Successful", parent=self.root)
                    self.clear()


            except Exception as es:
                messagebox.showerror("Error", f"Error due to: {str(es)}", parent=self.root)







root=Tk()
obj=Register(root)
root.mainloop()